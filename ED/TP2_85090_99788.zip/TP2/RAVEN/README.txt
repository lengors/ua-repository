Three  folders

1)- Overallaverages.  Features extracted in average signals.
2) - trialanalysis - features extracted in single trial signals. 
3) - trialRightWrong-  features extracted in single trials.  But splitted into rigth and wrong answers. 
The last column of the excel identifies the participant answering to that trial.